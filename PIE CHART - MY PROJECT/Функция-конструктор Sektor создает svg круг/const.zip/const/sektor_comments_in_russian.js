function Sektor(selector, options) {
// находим DOM объект. Создаем свойство element в новом конструируемом обьекте
// Теперь сохраним этот объект в свойство element  
  this.element = document.querySelector(selector);

// обьект с дефолтными параметрами этого круга
  const defaultOptions = {
    size: 100,
    circleColor: '#b3c9e0'
  };

// Влить в дефолтные значения полученные в конструктор аргументы
  options = Object.assign(defaultOptions, options);
	
// Подсчитать центр круга и радиус будущего круга и вписать в обьект как свойства
  options.center = options.size / 2;
  options.radius = options.center;
  
// Записываем в итоге полученный обьект с параметрами круга в свойство нового конструируемого обьекта 
  this.options = options;

// Создаем svg 
  const svg = this.getCircle();
  
// В новом конструируемом обьекте хранится DOM-элемент
// Теперь надо записать в свойство DOM-элемента всю разметку и содержание svg 
  this.element.innerHTML = svg;
}

// получаем параметрический обьект из нового конструируемого обьекта и вписываем его в свойство options 
Sektor.prototype.getCircle = function() {
  const options = this.options;
  return `
  <svg class='Sektor' viewBox='0 0 ${options.size} ${options.size}'> 
  <circle class='Sektor-circle' fill=${options.circleColor} cx='${options.center}' cy='${options.center}' r='${options.radius}' />
  </svg>
  `;
};